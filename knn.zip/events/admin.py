from django.contrib import admin
from .models import Event, EventRegistration

admin.site.register(Event)
admin.site.register(EventRegistration)