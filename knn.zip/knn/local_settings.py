EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 465
EMAIL_HOST_USER = 'testemailaarush@gmail.com'
EMAIL_HOST_PASSWORD = 'HELLOWORLD'
EMAIL_USE_SSL = True
